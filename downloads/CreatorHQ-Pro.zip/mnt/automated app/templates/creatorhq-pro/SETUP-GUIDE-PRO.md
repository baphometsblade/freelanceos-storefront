# CreatorHQ Pro -- Complete Setup Guide

Welcome to CreatorHQ Pro. This is the full system for managing your content creator business in Notion -- from ideation and scheduling through monetization, brand partnerships, and audience growth.

**Estimated setup time:** 30-45 minutes

---

## What You Get

CreatorHQ Pro includes seven interconnected databases:

| Database | File | Records | Purpose |
|----------|------|---------|---------|
| Content Calendar | `content-calendar.csv` | 10 entries | Plan, schedule, and track content across platforms |
| Ideas | `ideas.csv` | 12 entries | Capture and prioritize content ideas |
| Analytics | `analytics.csv` | 8 entries | Track views, engagement, and revenue per content piece |
| Brand Deals | `brand-deals.csv` | 6 entries | Manage sponsorship pipeline and deliverables |
| Monetization | `monetization.csv` | 10 entries | Track all revenue streams |
| Growth Log | `growth-log.csv` | 8 entries | Monitor follower growth and engagement rates |
| Collaborations | `collaborations.csv` | 5 entries | Track creator partnerships |

---

## Part 1: Import All Databases

### Import Order

Import in this order for easiest relation setup:

1. Content Calendar (the content hub)
2. Ideas
3. Analytics
4. Brand Deals
5. Monetization
6. Growth Log
7. Collaborations

### Import Process

1. Create a new page in Notion called **CreatorHQ Pro**.
2. Add an icon (suggested: rocket, lightning, or film camera) and cover image.
3. For each CSV: click **...** menu > **Import** > **CSV**.
4. Select the file and rename the resulting database.
5. Repeat for all seven files.

---

## Part 2: Configure Column Types

### Content Calendar

| Column | Set Type To | Notes |
|--------|------------|-------|
| Title | Title | Auto-set |
| Platform | Select | YouTube (red), Instagram (pink), TikTok (dark), Twitter (blue), Blog (green), Newsletter (orange) |
| Status | Select | Idea (gray), Drafting (yellow), Filming (orange), Editing (purple), Scheduled (blue), Published (green) |
| Publish Date | Date | |
| Content Type | Select | Video, Reel, Post, Story, Article |
| Topic | Select | Match to your content pillars |
| Notes | Text | Rich text |

### Ideas

| Column | Set Type To | Notes |
|--------|------------|-------|
| Idea Title | Title | |
| Category | Select | Match to your content categories |
| Priority | Select | Hot (red), Warm (orange), Cold (blue) |
| Source | Select | Audience Question, Trend, Original, Collaboration |
| Platform | Select | Same as Content Calendar |
| Status | Select | Backlog (gray), Researching (yellow), Ready (green) |
| Notes | Text | |

### Analytics

| Column | Set Type To | Notes |
|--------|------------|-------|
| Content Title | Title | |
| Platform | Select | |
| Publish Date | Date | |
| Views | Number | Commas format |
| Likes | Number | |
| Comments | Number | |
| Shares | Number | |
| Click-through Rate | Text | Or Number with Percent format |
| Revenue | Number | US Dollar |

### Brand Deals

| Column | Set Type To | Notes |
|--------|------------|-------|
| Brand Name | Title | |
| Contact | Email | |
| Status | Select | Pitched (gray), Negotiating (yellow), Active (blue), Complete (green), Declined (red) |
| Rate | Number | US Dollar |
| Deliverables | Text | Rich text |
| Platform | Multi-select | Deals often span multiple platforms |
| Deadline | Date | |
| Payment Status | Select | Pending (yellow), Received (green) |
| Notes | Text | |

### Monetization

| Column | Set Type To | Notes |
|--------|------------|-------|
| Date | Date | |
| Source | Select | Sponsorship (blue), Affiliate (green), Ad Revenue (orange), Course (purple), Merch (pink), Consulting (teal) |
| Amount | Number | US Dollar |
| Platform | Select | |
| Brand | Text | Will become Relation to Brand Deals |
| Status | Select | Pending (yellow), Received (green) |
| Notes | Text | |

### Growth Log

| Column | Set Type To | Notes |
|--------|------------|-------|
| Date | Date | |
| Platform | Select | |
| Followers | Number | Commas format |
| New Followers This Week | Number | |
| Engagement Rate | Text | Or Number with Percent |
| Top Content | Text | Will become Relation to Content Calendar |
| Notes | Text | |
| Goal | Text | |

### Collaborations

| Column | Set Type To | Notes |
|--------|------------|-------|
| Creator Name | Title | |
| Platform | Select | |
| Status | Select | Pitched (gray), Confirmed (blue), Complete (green) |
| Content Type | Select | Video, Reel, Article, etc. |
| Publish Date | Date | |
| Audience Size | Number | Commas format |
| Notes | Text | |

---

## Part 3: Database Relations Map

```
                 ┌──────────────────┐
                 │ CONTENT CALENDAR │
                 │   (Content Hub)  │
                 └────────┬─────────┘
                          │
        ┌─────────┬───────┼────────┬──────────────┐
        │         │       │        │              │
   ┌────▼──┐  ┌───▼───┐  │   ┌────▼─────┐  ┌────▼────────┐
   │ Ideas │  │Analytics│  │  │Growth Log│  │Collaborations│
   └───────┘  └────────┘  │  └──────────┘  └──────────────┘
                          │
                   ┌──────▼──────┐
                   │ Brand Deals │
                   └──────┬──────┘
                          │
                   ┌──────▼───────┐
                   │Monetization  │
                   └──────────────┘
```

### Setting Up All Relations

**Relation 1: Content Calendar → Ideas**
1. In Content Calendar, add a Relation to Ideas.
2. Name it "Source Idea." Reverse on Ideas: "Content Created."
3. Link content pieces to their originating ideas.

**Relation 2: Analytics → Content Calendar**
1. In Analytics, add a Relation to Content Calendar.
2. Name it "Content." Reverse on Content Calendar: "Performance."
3. Link each analytics entry to the content it measures.

**Relation 3: Brand Deals → Content Calendar**
1. In Brand Deals, add a Relation to Content Calendar.
2. Name it "Content Deliverables." Reverse on Content Calendar: "Brand Deal."
3. When you create content for a sponsor, link it here.

**Relation 4: Monetization → Brand Deals**
1. In Monetization, add a Relation to Brand Deals.
2. Name it "Deal." Reverse on Brand Deals: "Payments."
3. Link sponsorship payments to the deal they belong to.

**Relation 5: Monetization → Content Calendar**
1. In Monetization, add a Relation to Content Calendar.
2. Name it "Related Content." Reverse on Content Calendar: "Revenue."
3. Link ad revenue and affiliate income to the content that generated it.

**Relation 6: Growth Log → Content Calendar**
1. In Growth Log, replace the "Top Content" text column with a Relation to Content Calendar.
2. Name it "Top Content." Reverse on Content Calendar: "Growth Impact."
3. Track which content drives follower growth.

**Relation 7: Collaborations → Content Calendar**
1. In Collaborations, add a Relation to Content Calendar.
2. Name it "Collab Content." Reverse on Content Calendar: "Collaboration."
3. Link collaboration entries to the actual content produced.

**Relation 8: Collaborations → Ideas**
1. In Collaborations, add a Relation to Ideas.
2. Name it "Idea Source." Reverse on Ideas: "Collaboration."
3. Connect collab-sourced ideas to the collaboration record.

---

## Part 4: Formula Properties

### Analytics Formulas

**Engagement Rate**
Add a formula property:
```
if(prop("Views") > 0, round((prop("Likes") + prop("Comments") + prop("Shares")) / prop("Views") * 10000) / 100, 0)
```
This gives you a percentage showing total engagement relative to views.

**Revenue Per 1K Views (RPM)**
```
if(prop("Views") > 0, round(prop("Revenue") / prop("Views") * 1000 * 100) / 100, 0)
```
Key metric for understanding which content monetizes best.

### Brand Deals Formulas

**Days Until Deadline**
```
if(empty(prop("Deadline")), 0, dateBetween(prop("Deadline"), now(), "days"))
```

**Is Overdue**
```
if(and(prop("Status") == "Active", not(empty(prop("Deadline"))), prop("Deadline") < now()), true, false)
```

### Content Calendar Formulas

**Days Until Publish**
```
if(empty(prop("Publish Date")), 0, dateBetween(prop("Publish Date"), now(), "days"))
```

**Is Due Soon** (within 3 days)
```
if(and(prop("Status") != "Published", not(empty(prop("Publish Date"))), dateBetween(prop("Publish Date"), now(), "days") <= 3, dateBetween(prop("Publish Date"), now(), "days") >= 0), true, false)
```

### Monetization Rollups on Content Calendar

**Total Revenue (Rollup)**
1. Add a Rollup property on Content Calendar.
2. Relation: Revenue (Monetization).
3. Property: Amount.
4. Calculate: Sum.
5. See how much money each piece of content has generated.

### Brand Deals Rollups

**Total Paid (Rollup)**
1. Add a Rollup on Brand Deals.
2. Relation: Payments (Monetization).
3. Property: Amount.
4. Calculate: Sum.
5. Track actual payments received vs. agreed rate.

---

## Part 5: View Configurations (18 Views)

### Content Calendar (4 Views)

1. **Content Pipeline** -- Board view grouped by Status. Columns: Idea | Drafting | Filming | Editing | Scheduled | Published. Your primary workflow view.

2. **Publishing Schedule** -- Calendar view on Publish Date. See your posting schedule at a glance. Spot empty days and double-bookings.

3. **By Platform** -- Table grouped by Platform. Ensure balanced content distribution. Shows post counts per platform.

4. **This Week** -- Table filtered to Publish Date is within the next 7 days. Sorted by Publish Date ascending. Your "what do I need to work on right now" view.

### Ideas Database (3 Views)

5. **Idea Board** -- Board grouped by Status. Columns: Backlog | Researching | Ready.

6. **Hot Ideas** -- Table filtered to Priority = Hot. Sorted by Status (Ready first). Your "next up" list.

7. **By Source** -- Table grouped by Source. Identify where your best ideas come from. If most come from audience questions, invest more in community engagement.

### Analytics Database (3 Views)

8. **Top Performers** -- Table sorted by Views descending. Study what works.

9. **Revenue Leaderboard** -- Table sorted by Revenue descending. Filter to Revenue > 0. See which content makes money.

10. **By Platform** -- Table grouped by Platform. Compare performance across platforms to decide where to focus.

### Brand Deals Database (2 Views)

11. **Deal Pipeline** -- Board grouped by Status. Columns: Pitched | Negotiating | Active | Complete | Declined. Visual pipeline for your sponsorship business.

12. **Active Deals** -- Table filtered to Status = Active or Negotiating. Shows Deadline, Rate, Deliverables. Your "what I owe brands" view.

### Monetization Database (3 Views)

13. **All Revenue** -- Table sorted by Date descending. Sum the Amount column at the bottom for total revenue.

14. **By Source** -- Table grouped by Source. See revenue breakdown: Sponsorship vs. Affiliate vs. Ad Revenue vs. Course vs. Merch vs. Consulting. Critical for understanding your income mix.

15. **Monthly Revenue** -- Table grouped by month (using Date). Track monthly income trends over time.

### Growth Log (2 Views)

16. **Growth Timeline** -- Table sorted by Date descending. Track follower counts and engagement rates over time.

17. **By Platform** -- Table grouped by Platform. Compare growth rates across platforms. Identify where momentum is building.

### Collaborations (1 View)

18. **Collab Pipeline** -- Board grouped by Status. Columns: Pitched | Confirmed | Complete.

---

## Part 6: Revenue Dashboard Setup

The revenue dashboard is the centerpiece of CreatorHQ Pro. It gives you a single-page view of your creator business finances.

### Dashboard Layout

Create a new page called **Revenue Dashboard** inside your CreatorHQ Pro workspace.

**Row 1: Revenue Summary (Callout Blocks in Columns)**

Create three columns with callout blocks:
- **This Month's Revenue:** Link to Monetization filtered to current month, show sum of Amount
- **Pending Payments:** Link to Monetization filtered to Status = Pending, show sum
- **Active Brand Deals:** Link to Brand Deals filtered to Status = Active, show count and total Rate

**Row 2: Revenue by Source**
- Linked view of Monetization -- By Source view.
- At a glance, see your income diversification.

**Row 3: Two Columns**

Left column -- "Brand Deal Pipeline":
- Linked view of Brand Deals in Board view.

Right column -- "Pending Payments":
- Linked view of Monetization filtered to Status = Pending.
- Sorted by Amount descending.

**Row 4: Monthly Trend**
- Linked view of Monetization -- Monthly Revenue view.
- Shows income trajectory over time.

---

## Part 7: Content Performance Tracking

This workflow connects your content creation to real results.

### The Full Loop

```
Idea → Content Calendar → Published → Analytics → Revenue (Monetization)
  ↑                                       │
  └───── Insights feed new ideas ─────────┘
```

### Weekly Performance Review Workflow

Every week, follow this process:

1. **Pull analytics data.** Go to each platform (YouTube Studio, Instagram Insights, TikTok Analytics, etc.) and record numbers in the Analytics database for content published that week.

2. **Log revenue.** Check payment dashboards (AdSense, affiliate programs, Stripe) and create entries in Monetization.

3. **Update Growth Log.** Record current follower counts and engagement rates for each platform.

4. **Review top performers.** Open Analytics -- Top Performers view. Ask: what topic, format, and platform performed best? Add new ideas to the Ideas database based on what worked.

5. **Check brand deal deadlines.** Open Brand Deals -- Active Deals view. Ensure all deliverables are on track.

### Setting Up a Performance Template

Create a database template in Content Calendar called "Post-Publish Checklist" with these items in the page body:
- [ ] Published on platform
- [ ] Cross-promoted on other platforms
- [ ] Added to Analytics database (after 48 hours)
- [ ] Linked to Monetization if revenue-generating
- [ ] Responded to comments (first 24 hours)
- [ ] Added to Growth Log if significant impact

---

## Part 8: Automation Tips

### Recurring Entries
- Create database templates for weekly analytics entries, monthly growth log entries, and recurring revenue (like AdSense payouts).

### Notion Buttons
Add button blocks to your dashboard:
- "Log Revenue" -- creates a new Monetization entry with today's date.
- "New Content Idea" -- creates a new Ideas entry with Status = Backlog.
- "Record Analytics" -- creates a new Analytics entry with today's date.

### External Automation (Zapier / Make)
- Auto-create a Monetization entry when a Stripe payment is received.
- Pull YouTube analytics via API and auto-populate the Analytics database.
- Send yourself a Slack message when a Brand Deal deadline is 3 days away.
- Auto-move Content Calendar items to "Published" when the Publish Date arrives.

### Reminders
- Set reminders on Brand Deal deadlines (7 days before, 1 day before).
- Set reminders on Publish Dates for content that needs to be filmed or edited.

---

## Part 9: Replacing Sample Data

1. **Use the samples as your guide** for 1-2 weeks while learning the system.
2. **Add your real data** alongside the samples.
3. **Delete sample entries** once you are comfortable. Select rows and press Delete.
4. **Keep the database structure.** The columns, relations, formulas, and views are the valuable part -- the sample data is just to demonstrate how it all fits together.

---

## Recommended Daily Workflow

**Morning (5 minutes)**
1. Open the Content Pipeline board. What is due today?
2. Check Brand Deals -- Active Deals for any upcoming deadlines.
3. Glance at Revenue Dashboard for motivation.

**During Content Creation**
1. Move content cards through the pipeline as you work (Drafting → Filming → Editing → Scheduled).
2. Log any new ideas that come up during creation.

**Post-Publishing**
1. Move content to Published status.
2. Cross-promote on other platforms.
3. Set a reminder to pull analytics in 48 hours.

**Weekly Review (30 minutes)**
1. Pull analytics for all published content.
2. Log revenue from all sources.
3. Update Growth Log with current follower counts.
4. Review Brand Deal pipeline and follow up on pitched deals.
5. Move Hot ideas from Ready to Content Calendar with planned publish dates.
6. Review Collaborations and follow up on pitched collabs.

**Monthly Review (1 hour)**
1. Analyze revenue trends in Monthly Revenue view.
2. Identify top-performing content and brainstorm similar ideas.
3. Review platform growth rates. Adjust strategy for underperforming platforms.
4. Evaluate brand deal pipeline. Pitch new brands if pipeline is thin.
5. Set goals for next month in Growth Log.

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Cmd/Ctrl + K | Quick search |
| Cmd/Ctrl + N | New page |
| Cmd/Ctrl + Shift + L | Toggle dark mode |
| Cmd/Ctrl + \ | Toggle sidebar |
| / | Block menu |
| @ | Mention page, person, or date |

---

## Troubleshooting

**CSV columns not detected correctly**
- Ensure the file uses comma separators. Open in a text editor to verify.
- Fields containing commas should be wrapped in quotes (they are in these files).

**Relations not linking**
- Search for the exact entry name when linking.
- Verify you selected the correct target database.

**Formulas showing errors**
- Property names in formulas are case-sensitive. Match them exactly.
- Ensure referenced properties exist and have the correct type.

**Views not filtering correctly**
- Double-check filter conditions: "Is" vs "Contains" vs "Is not."
- Multiple filters default to AND logic. Use OR if needed.

---

## Need Help?

- **Notion Help Center:** https://www.notion.so/help
- **Support:** Reply to your purchase confirmation email for setup assistance.

You now have a complete system for managing your creator business. Plan content, track performance, manage brand deals, and watch your growth -- all in one workspace.
