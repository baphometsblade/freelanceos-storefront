# FreelanceOS Pro -- Complete Setup Guide

Welcome to FreelanceOS Pro. This is the full system for running your freelance business in Notion -- from client acquisition through invoicing, time tracking, finances, and contract management.

**Estimated setup time:** 30-45 minutes (worth every minute)

---

## What You Get

FreelanceOS Pro includes seven interconnected databases:

| Database | File | Records | Purpose |
|----------|------|---------|---------|
| Clients | `clients.csv` | 5 entries | Central client hub -- every other database connects here |
| Projects | `projects.csv` | 8 entries | Track scope, budget, hours, and status |
| Invoices | `invoices.csv` | 6 entries | Billing pipeline from draft to paid |
| Time Log | `time-log.csv` | 15 entries | Daily time entries with rates and categories |
| Finances | `finances.csv` | 12 entries | Income, expenses, and tax tracking |
| Proposals | `proposals.csv` | 4 entries | Proposal pipeline from draft to accepted |
| Contracts | `contracts.csv` | 4 entries | Active agreements and renewal tracking |

---

## Part 1: Import All Databases

### Import Order

Import in this order so relations are easier to set up:

1. Clients (the hub -- everything connects to this)
2. Projects
3. Invoices
4. Time Log
5. Finances
6. Proposals
7. Contracts

### Import Process (Repeat for Each CSV)

1. Open Notion and create a new page called **FreelanceOS Pro**.
2. Add an icon (suggested: rocket or briefcase) and a cover image.
3. Click the **...** menu > **Import** > **CSV**.
4. Select the CSV file.
5. Rename the created database.
6. Repeat for all seven files.

---

## Part 2: Configure Column Types

After importing, adjust each database's column types. Notion auto-detects some types, but you need to verify and correct others.

### Clients Database

| Column | Set Type To | Format/Notes |
|--------|------------|--------------|
| Client Name | Title | Auto-set |
| Status | Select | Active (green), Prospect (yellow), Past (gray) |
| Contact Email | Email | Clickable email links |
| Phone | Phone | Clickable phone links |
| Industry | Select | Auto-detect should work |
| Monthly Retainer | Number | US Dollar format |
| Notes | Text | Rich text |
| Last Contact Date | Date | Change from text |

### Projects Database

| Column | Set Type To | Format/Notes |
|--------|------------|--------------|
| Project Name | Title | Auto-set |
| Client | Text | Will become Relation |
| Status | Select | Not Started (gray), In Progress (blue), Review (yellow), Complete (green) |
| Priority | Select | High (red), Medium (yellow), Low (gray) |
| Deadline | Date | |
| Budget | Number | US Dollar |
| Hours Estimated | Number | |
| Hours Actual | Number | |
| Description | Text | Rich text |

### Invoices Database

| Column | Set Type To | Format/Notes |
|--------|------------|--------------|
| Invoice Number | Title | Auto-set |
| Client | Text | Will become Relation |
| Amount | Number | US Dollar |
| Status | Select | Draft (gray), Sent (blue), Paid (green), Overdue (red) |
| Issue Date | Date | |
| Due Date | Date | |
| Payment Method | Select | |
| Notes | Text | |

### Time Log Database

| Column | Set Type To | Format/Notes |
|--------|------------|--------------|
| Date | Date | Change from Title if needed |
| Client | Text | Will become Relation |
| Project | Text | Will become Relation |
| Hours | Number | Number format, 1 decimal |
| Hourly Rate | Number | US Dollar |
| Total | Number | Will become Formula later |
| Category | Select | Design (purple), Dev (blue), Meetings (yellow), Admin (gray) |
| Notes | Text | |
| Billable | Checkbox | Convert Yes/No to checkbox |

### Finances Database

| Column | Set Type To | Format/Notes |
|--------|------------|--------------|
| Date | Date | |
| Description | Title | |
| Category | Select | Income (green), Expense (red), Tax (orange) |
| Amount | Number | US Dollar (negative for expenses) |
| Client | Text | Will become Relation |
| Payment Method | Select | |
| Tax Deductible | Checkbox | Convert Yes/No to checkbox |
| Receipt | URL | For linking to stored receipts |
| Notes | Text | |

### Proposals Database

| Column | Set Type To | Format/Notes |
|--------|------------|--------------|
| Proposal Title | Title | |
| Client | Text | Will become Relation |
| Status | Select | Draft (gray), Sent (blue), Accepted (green), Declined (red) |
| Amount | Number | US Dollar |
| Sent Date | Date | |
| Valid Until | Date | |
| Scope Summary | Text | Rich text |

### Contracts Database

| Column | Set Type To | Format/Notes |
|--------|------------|--------------|
| Contract Name | Title | |
| Client | Text | Will become Relation |
| Status | Select | Active (green), Expired (gray), Pending (yellow) |
| Start Date | Date | |
| End Date | Date | |
| Value | Number | US Dollar |
| Type | Select | Retainer (blue), Project (purple), Hourly (orange) |
| File Link | URL | Link to contract PDF/doc |

---

## Part 3: Database Relations Map

This is the core architecture of FreelanceOS Pro. Every database connects to create a unified system.

```
                    ┌──────────────┐
                    │   CLIENTS    │
                    │  (Hub)       │
                    └──────┬───────┘
                           │
          ┌────────┬───────┼───────┬──────────┬──────────┐
          │        │       │       │          │          │
     ┌────▼──┐ ┌───▼───┐ ┌▼────┐ ┌▼───────┐ ┌▼───────┐ ┌▼────────┐
     │Projects│ │Invoices│ │Time │ │Finances│ │Proposals│ │Contracts│
     └───┬────┘ └───────┘ │Log  │ └────────┘ └─────────┘ └─────────┘
         │                 └──┬──┘
         │                    │
         └────────────────────┘
         (Time Log also links to Projects)
```

### Setting Up All Relations

Complete these in order:

**Relation 1: Projects → Clients**
1. In Projects, add a Relation property pointing to Clients.
2. Enable "Show on Clients" -- name the reverse property "Projects."
3. Link each project to its client.
4. Delete the old text-based Client column.

**Relation 2: Invoices → Clients**
1. In Invoices, add a Relation to Clients.
2. Reverse property on Clients: "Invoices."
3. Link each invoice. Delete old text column.

**Relation 3: Invoices → Projects**
1. In Invoices, add a Relation to Projects.
2. Reverse property on Projects: "Invoices."

**Relation 4: Time Log → Clients**
1. In Time Log, add a Relation to Clients.
2. Reverse property on Clients: "Time Entries."
3. Link each time entry. Delete old text column.

**Relation 5: Time Log → Projects**
1. In Time Log, add a Relation to Projects.
2. Reverse property on Projects: "Time Entries."
3. Link each time entry. Delete old text column.

**Relation 6: Finances → Clients**
1. In Finances, add a Relation to Clients.
2. Reverse property on Clients: "Transactions."
3. Link entries that have a client. Delete old text column.

**Relation 7: Proposals → Clients**
1. In Proposals, add a Relation to Clients.
2. Reverse property on Clients: "Proposals."
3. Link each proposal. Delete old text column.

**Relation 8: Contracts → Clients**
1. In Contracts, add a Relation to Clients.
2. Reverse property on Clients: "Contracts."
3. Link each contract. Delete old text column.

**Relation 9: Contracts → Projects (Optional)**
1. In Contracts, add a Relation to Projects.
2. Links contracts to the projects they govern.

After all relations are set, the Clients database becomes your central hub. Opening any client page shows their projects, invoices, time entries, financial transactions, proposals, and contracts -- all in one place.

---

## Part 4: Formula Properties

Formulas automate calculations so you never have to do math manually. Add these formula properties to the relevant databases.

### Time Log Formulas

**Auto-Calculate Total**
Replace the imported "Total" number column with a Formula:
```
prop("Hours") * prop("Hourly Rate")
```
This automatically calculates the dollar amount for each time entry.

### Projects Formulas

**Budget Remaining**
Add a new Formula property called "Budget Remaining":
```
prop("Budget") - prop("Hours Actual") * 125
```
(Replace 125 with your standard hourly rate, or create an Hourly Rate property on Projects.)

**Hours Remaining**
```
prop("Hours Estimated") - prop("Hours Actual")
```

**Completion Percentage**
```
if(prop("Hours Estimated") > 0, round(prop("Hours Actual") / prop("Hours Estimated") * 100), 0)
```

**Budget Utilization**
```
if(prop("Budget") > 0, round(prop("Hours Actual") * 125 / prop("Budget") * 100), 0)
```

### Invoices Formulas

**Days Until Due**
```
if(prop("Status") == "Paid", 0, dateBetween(prop("Due Date"), now(), "days"))
```

**Is Overdue** (Checkbox-style formula)
```
if(and(prop("Status") != "Paid", prop("Due Date") < now()), true, false)
```

### Contracts Formulas

**Days Until Expiry**
```
dateBetween(prop("End Date"), now(), "days")
```

**Is Expiring Soon** (within 30 days)
```
if(and(prop("Status") == "Active", dateBetween(prop("End Date"), now(), "days") <= 30), true, false)
```

### Clients Formulas (using Rollups)

Before adding these, you need **Rollup** properties:

**Total Revenue (Rollup)**
1. Add a Rollup property on Clients.
2. Relation: Invoices.
3. Property: Amount.
4. Calculate: Sum.
5. Filter: Only where Status is "Paid."

**Total Hours Logged (Rollup)**
1. Add a Rollup on Clients.
2. Relation: Time Entries.
3. Property: Hours.
4. Calculate: Sum.

**Active Projects Count (Rollup)**
1. Add a Rollup on Clients.
2. Relation: Projects.
3. Property: Status.
4. Calculate: Count where Status is not "Complete."

---

## Part 5: View Configurations (15+ Views)

### Clients Database (4 Views)

1. **All Clients** -- Default table sorted by Status then Client Name.
2. **Active Clients** -- Table filtered to Status = Active. Show: Name, Industry, Monthly Retainer, Projects (rollup count), Total Revenue.
3. **Client Cards** -- Gallery view. Card preview: Name, Industry, Monthly Retainer. Good for quick visual scanning.
4. **Follow-Up Needed** -- Table filtered to Last Contact Date is more than 14 days ago. Sorted by Last Contact Date ascending. Helps you stay in touch.

### Projects Database (3 Views)

5. **Project Board** -- Board view grouped by Status. Columns: Not Started | In Progress | Review | Complete. Show Priority as a colored label.
6. **Deadline Calendar** -- Calendar view on Deadline property.
7. **By Client** -- Table grouped by Client relation. Shows all projects organized under each client.

### Invoices Database (3 Views)

8. **Invoice Pipeline** -- Board view grouped by Status. Columns: Draft | Sent | Paid | Overdue.
9. **Due Date Calendar** -- Calendar view on Due Date.
10. **Outstanding Invoices** -- Table filtered to Status is not Paid. Sorted by Due Date ascending. This is your "chase these" view.

### Time Log Database (3 Views)

11. **This Week** -- Table filtered to Date is within the past 7 days. Grouped by Date. Shows daily breakdown.
12. **By Client** -- Table grouped by Client. Useful for seeing how time distributes across clients.
13. **Billable Only** -- Table filtered to Billable = Yes. Add a Sum calculation at the bottom of the Total column to see billable revenue.

### Finances Database (3 Views)

14. **Monthly Overview** -- Table grouped by month (using Date property). Shows running totals.
15. **Income Only** -- Table filtered to Category = Income. Sum the Amount column for total income.
16. **Tax Deductible Expenses** -- Table filtered to Tax Deductible = Yes AND Category = Expense. Essential at tax time.

### Proposals Database (1 View)

17. **Proposal Pipeline** -- Board view grouped by Status. Columns: Draft | Sent | Accepted | Declined.

### Contracts Database (1 View)

18. **Contract Status** -- Table sorted by End Date ascending. Highlight expiring contracts with conditional formatting or the "Is Expiring Soon" formula.

---

## Part 6: Dashboard Setup

Your dashboard is a single page that surfaces the most important information from every database.

### Dashboard Layout

Create a new page or use your top-level FreelanceOS Pro page. Build it in this order:

**Row 1: Key Metrics (use Callout blocks)**
Create three callout blocks side by side (use columns):
- Total Revenue This Month: manually update, or link to a filtered Finances view
- Outstanding Invoices: count from your Outstanding Invoices view
- Hours Logged This Week: sum from your This Week time log view

**Row 2: Active Work**
- Add a linked view of Projects in Board view, filtered to Status is not "Complete."
- This is your primary working view.

**Row 3: Two Columns**
Left column:
- Linked view of Outstanding Invoices (table, compact)
- Linked view of Proposals with Status = Sent (table, compact)

Right column:
- Linked view of Time Log -- This Week (table)
- Linked view of Contracts where Is Expiring Soon = true

**Row 4: Financial Snapshot**
- Linked view of Finances -- Monthly Overview (table)
- Linked view of Finances -- Income Only with sum

**Row 5: Follow-Ups**
- Linked view of Clients -- Follow-Up Needed
- Quick reference for clients who need attention

### Building Linked Views

To create a linked view:
1. Type `/linked` in the page.
2. Select **Linked view of database**.
3. Choose the source database.
4. Select or create the view you want to display.
5. Optionally add additional filters specific to this linked view (these will not affect the original database views).

---

## Part 7: Automation Tips

Notion does not have built-in automation triggers, but you can use these strategies:

### Recurring Reminders
- On the Contracts database, set reminders on End Date properties (30 days before, 7 days before).
- On Invoices, set reminders on Due Date.

### Templates for Repeating Entries
Create database templates for:
- **Monthly retainer invoice:** Pre-fill amount, payment method, and client for each retainer client.
- **Weekly time log:** Pre-fill a week's worth of date entries.
- **New client onboarding:** A template with checklist of steps (send contract, set up project, create first invoice).

To create a template: Open a database, click the dropdown arrow next to **New**, then **+ New template**.

### External Automation (Advanced)
Connect Notion to Zapier or Make (formerly Integromat) to:
- Auto-create an invoice when a project status changes to "Complete."
- Send a Slack notification when a proposal is accepted.
- Add a time log entry from Toggl or Harvest.
- Move overdue invoices to "Overdue" status automatically.

### Buttons (Notion Buttons Feature)
Use Notion's button blocks to create one-click actions:
- "New Time Entry" button that creates a time log entry with today's date pre-filled.
- "New Invoice" button that opens the invoice template.

---

## Part 8: Replacing Sample Data

Once your system is configured:

1. **Do not delete sample data yet.** Use it as reference while you learn the system.
2. **Start adding real data** alongside the samples for a week.
3. **Once comfortable,** select all sample rows and delete them.
4. **Back up your workspace** before bulk changes: Settings > Export all workspace content.

---

## Recommended Workflow

Here is how to use FreelanceOS Pro day-to-day:

**Start of Day**
1. Open your dashboard.
2. Check the Project Board for today's priorities.
3. Review Outstanding Invoices for any overdue items.

**During Work**
1. Log time entries as you work (or batch at end of day).
2. Update project status as tasks move through stages.

**End of Week**
1. Review Time Log -- This Week view for billable hours.
2. Send any draft invoices that are ready.
3. Check Follow-Up Needed for clients to contact.
4. Log any expenses from the week.

**End of Month**
1. Review Finances -- Monthly Overview.
2. Send all outstanding invoices.
3. Check contracts for upcoming renewals.
4. Update client retainer invoices for next month.

---

## Keyboard Shortcuts for Faster Navigation

| Shortcut | Action |
|----------|--------|
| Cmd/Ctrl + K | Quick search -- jump to any page or database |
| Cmd/Ctrl + N | New page |
| Cmd/Ctrl + Shift + L | Toggle dark mode |
| Cmd/Ctrl + \ | Toggle sidebar |
| / | Open block menu for quick commands |
| @ | Mention a page, person, or date |
| Cmd/Ctrl + D | Duplicate current block |

---

## Troubleshooting

**CSV columns are not detected correctly**
- Open the CSV in a text editor and verify it uses commas (not semicolons or tabs).
- Ensure there are no extra commas in text fields. Quoted fields handle this automatically.

**Relations are not linking**
- Make sure you are clicking the relation cell and searching for the exact entry name.
- Check that you selected the correct target database when creating the relation.

**Formulas show errors**
- Verify property names in formulas match exactly (case-sensitive).
- Ensure the properties referenced exist and are the correct type (Number, Date, etc.).

**Views are not filtering correctly**
- Check filter conditions carefully. "Is" vs "Contains" vs "Is not" matter.
- Multiple filters use AND logic by default. Switch to OR if needed.

---

## Need Help?

- **Notion Help Center:** https://www.notion.so/help
- **Support:** Reply to your purchase confirmation email for setup assistance.

You now have a professional-grade freelance management system. The time you invest in setup pays for itself within the first week of use.
