# FreelanceOS Lite -- Setup Guide

Welcome to FreelanceOS Lite. This guide walks you through importing the CSV files into Notion, connecting your databases, and building views that make managing your freelance business feel effortless.

**Estimated setup time:** 15-20 minutes

---

## What You Get

FreelanceOS Lite includes three databases pre-loaded with realistic sample data:

| Database | File | Records | Purpose |
|----------|------|---------|---------|
| Clients | `clients.csv` | 5 entries | Track client contacts, status, and retainers |
| Projects | `projects.csv` | 8 entries | Manage project timelines, budgets, and progress |
| Invoices | `invoices.csv` | 6 entries | Monitor invoicing and payment status |

---

## Step 1: Create Your Workspace Page

1. Open Notion and navigate to your sidebar.
2. Click **+ Add a page** in the sidebar.
3. Name the page **FreelanceOS** (or whatever you prefer).
4. Choose the **Empty page** option -- do not select a template.
5. Optionally, add an icon (suggested: briefcase) and a cover image.

This page will serve as your dashboard, housing all three databases.

---

## Step 2: Import the Clients Database

1. Inside your FreelanceOS page, type `/` and select **Table - Inline** to create a new inline database. Alternatively, you can import directly.
2. **To import:** Click the **...** menu in the top-right corner of the page, then select **Import** > **CSV**.
3. Select the `clients.csv` file from your downloads.
4. Notion will create a new database with all columns auto-detected.
5. Rename the database title to **Clients**.

### Configure Column Types

After import, verify and adjust these column types by clicking each column header:

| Column | Type | Notes |
|--------|------|-------|
| Client Name | Title | Auto-set by Notion |
| Status | Select | Add options: Active (green), Prospect (yellow), Past (gray) |
| Contact Email | Email | Change from Text to Email type for clickable links |
| Phone | Phone | Change from Text to Phone type |
| Industry | Select | Notion may auto-detect this |
| Monthly Retainer | Number | Set format to US Dollar |
| Notes | Text | Keep as rich text |
| Last Contact Date | Date | Change from Text to Date type |

---

## Step 3: Import the Projects Database

1. Repeat the import process: **...** menu > **Import** > **CSV**.
2. Select `projects.csv`.
3. Rename the database to **Projects**.

### Configure Column Types

| Column | Type | Notes |
|--------|------|-------|
| Project Name | Title | Auto-set |
| Client | Text | We will convert this to a Relation later |
| Status | Select | Options: Not Started (gray), In Progress (blue), Review (yellow), Complete (green) |
| Priority | Select | Options: High (red), Medium (yellow), Low (gray) |
| Deadline | Date | Change from Text to Date |
| Budget | Number | Set format to US Dollar |
| Hours Estimated | Number | Set format to Number |
| Hours Actual | Number | Set format to Number |
| Description | Text | Keep as rich text |

---

## Step 4: Import the Invoices Database

1. Import `invoices.csv` using the same process.
2. Rename the database to **Invoices**.

### Configure Column Types

| Column | Type | Notes |
|--------|------|-------|
| Invoice Number | Title | Auto-set |
| Client | Text | Will become a Relation |
| Amount | Number | Set format to US Dollar |
| Status | Select | Options: Draft (gray), Sent (blue), Paid (green), Overdue (red) |
| Issue Date | Date | Change from Text to Date |
| Due Date | Date | Change from Text to Date |
| Payment Method | Select | Options: Bank Transfer, Stripe, PayPal |
| Notes | Text | Keep as rich text |

---

## Step 5: Set Up Relations Between Databases

Relations are what turn three separate spreadsheets into a connected system. This is where Notion becomes powerful.

### Relation 1: Projects to Clients

1. Open the **Projects** database in full page view.
2. Click the **+** button to add a new property (column).
3. Select **Relation** as the property type.
4. Choose the **Clients** database as the target.
5. Enable **Show on Clients** so you can see related projects from the client view too.
6. Name the property on Projects: **Client** (replace the text column).
7. Name the reverse property on Clients: **Projects**.
8. For each project row, click the Client relation cell and link it to the correct client.

### Relation 2: Invoices to Clients

1. In the **Invoices** database, add a new **Relation** property.
2. Connect it to the **Clients** database.
3. Enable **Show on Clients** -- name the reverse property **Invoices**.
4. Link each invoice to the correct client.

### Relation 3: Invoices to Projects (Optional)

1. In the **Invoices** database, add another **Relation** property.
2. Connect it to the **Projects** database.
3. This lets you track which invoices relate to which projects.

After setting up relations, you can delete the old text-based "Client" columns that were imported from the CSV.

---

## Step 6: Create Views

Views let you see the same data in different ways. Here are the essential views to set up for each database.

### Clients Database Views

**View 1: All Clients (Default Table)**
- Already set up from import. Sort by Status.

**View 2: Active Clients Only**
1. Click **+ Add a view** at the top of the database.
2. Choose **Table** view.
3. Name it "Active Clients."
4. Add a filter: Status is "Active."

**View 3: Client Gallery**
1. Add a new view, choose **Gallery**.
2. Name it "Client Cards."
3. Set the card preview to show: Client Name, Industry, Monthly Retainer.
4. This gives you a visual overview -- like a CRM card view.

### Projects Database Views

**View 1: Kanban Board**
1. Add a new view, choose **Board**.
2. Name it "Project Board."
3. Group by: **Status**.
4. The columns will be: Not Started | In Progress | Review | Complete.
5. Drag cards between columns to update project status.

*This is the view you will use most often. It gives you an instant snapshot of where every project stands.*

**View 2: Calendar**
1. Add a new view, choose **Calendar**.
2. Name it "Deadlines."
3. Set the date property to **Deadline**.
4. Now you can see all project deadlines on a monthly calendar.

**View 3: By Priority**
1. Add a Table view named "By Priority."
2. Group by: **Priority**.
3. Sort by: **Deadline** (ascending).

### Invoices Database Views

**View 1: Kanban by Status**
1. Add a **Board** view named "Invoice Pipeline."
2. Group by: **Status**.
3. Columns: Draft | Sent | Paid | Overdue.

**View 2: Calendar**
1. Add a **Calendar** view named "Due Dates."
2. Set date property to **Due Date**.
3. Useful for seeing payment deadlines at a glance.

**View 3: Unpaid Only**
1. Add a **Table** view named "Outstanding."
2. Filter: Status is not "Paid."
3. Sort by: Due Date (ascending).

---

## Step 7: Build Your Dashboard

Now tie everything together on your main FreelanceOS page.

1. Go to your top-level FreelanceOS page.
2. Add a **Heading 2**: "Active Projects"
3. Below it, create a **Linked view of database** (type `/linked`) pointing to your Projects database. Set it to the Kanban view. Filter to show only "In Progress" and "Review."
4. Add another **Heading 2**: "Upcoming Invoices"
5. Add a linked view of Invoices, filtered to Status is not "Paid," sorted by Due Date.
6. Add a **Heading 2**: "Client Overview"
7. Add a linked view of Clients in Gallery view, filtered to Active only.

This single page becomes your daily command center.

---

## Step 8: Customize Your Data

The sample data is here to show you how the system works. Once you understand the structure:

1. **Replace sample data** with your real clients, projects, and invoices.
2. **Add new Select options** as needed (new industries, payment methods, etc.).
3. **Customize colors** on your Select/Status properties to match your preferences.
4. **Add properties** you need -- maybe a "Referred By" field on Clients, or a "Contract Link" on Projects.

---

## Tips for Getting the Most Out of FreelanceOS Lite

- **Use the Kanban board daily.** Drag projects between columns as work progresses. It takes 2 seconds and keeps everything accurate.
- **Log invoices immediately.** When you send an invoice, create the entry right away while the details are fresh.
- **Set reminders.** On any database entry, you can set a reminder on a date property. Use this for follow-ups and deadlines.
- **Use the mobile app.** Notion's mobile app lets you update project status and check invoices on the go.

---

## What's Missing (And What Pro Adds)

FreelanceOS Lite gives you the core system, but growing freelancers often need more. Here is what the **FreelanceOS Pro** template adds:

| Feature | Lite | Pro |
|---------|------|-----|
| Client Management | 1 database | 1 database |
| Project Tracking | 1 database | 1 database |
| Invoicing | 1 database | 1 database |
| **Time Tracking** | -- | Full time log with hourly rates and auto-totals |
| **Financial Dashboard** | -- | Income, expenses, and tax tracking in one view |
| **Proposals** | -- | Send and track proposals with status pipeline |
| **Contracts** | -- | Contract management with expiration alerts |
| **Automated Formulas** | -- | Revenue calculations, utilization rate, profit margins |
| **15+ Pre-built Views** | 9 views | 15+ views including financial dashboards |
| **Database Relations** | 3 relations | 12+ cross-database relations |

**Ready to run your freelance business like a real business?**
Upgrade to FreelanceOS Pro for $29 -- a one-time purchase that includes the full linked system, formula templates, and a complete setup guide.

[Get FreelanceOS Pro →]

---

## Need Help?

- **Notion's official import guide:** https://www.notion.so/help/import-data-into-notion
- **Questions about setup?** Reply to your purchase confirmation email and we will help you get set up.

Happy freelancing.
