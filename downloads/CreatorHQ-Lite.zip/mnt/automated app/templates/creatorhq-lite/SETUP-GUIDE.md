# CreatorHQ Lite -- Setup Guide

Welcome to CreatorHQ Lite. This guide walks you through importing the CSV files into Notion and setting up a content management system that helps you plan, track, and grow your creator business.

**Estimated setup time:** 15-20 minutes

---

## What You Get

CreatorHQ Lite includes three databases:

| Database | File | Records | Purpose |
|----------|------|---------|---------|
| Content Calendar | `content-calendar.csv` | 10 entries | Plan and schedule content across all platforms |
| Ideas | `ideas.csv` | 12 entries | Capture and prioritize content ideas |
| Analytics | `analytics.csv` | 8 entries | Track performance metrics for published content |

---

## Step 1: Create Your Workspace Page

1. Open Notion and click **+ Add a page** in the sidebar.
2. Name it **CreatorHQ** (or your preferred name).
3. Select **Empty page**.
4. Add an icon (suggested: video camera or lightning bolt) and a cover image.

---

## Step 2: Import the Content Calendar

1. On your CreatorHQ page, click **...** menu > **Import** > **CSV**.
2. Select `content-calendar.csv`.
3. Rename the database to **Content Calendar**.

### Configure Column Types

| Column | Set Type To | Notes |
|--------|------------|-------|
| Title | Title | Auto-set |
| Platform | Select | YouTube (red), Instagram (pink), TikTok (dark), Twitter (blue), Blog (green), Newsletter (orange) |
| Status | Select | Idea (gray), Drafting (yellow), Filming (orange), Editing (purple), Scheduled (blue), Published (green) |
| Publish Date | Date | Change from text |
| Content Type | Select | Video, Reel, Post, Story, Article |
| Topic | Select | Create categories that match your niche |
| Notes | Text | Rich text |

---

## Step 3: Import the Ideas Database

1. Import `ideas.csv` using the same process.
2. Rename to **Ideas**.

### Configure Column Types

| Column | Set Type To | Notes |
|--------|------------|-------|
| Idea Title | Title | Auto-set |
| Category | Select | Create categories matching your content pillars |
| Priority | Select | Hot (red), Warm (orange), Cold (blue) |
| Source | Select | Audience Question (green), Trend (yellow), Original (purple), Collaboration (blue) |
| Platform | Select | Same options as Content Calendar |
| Status | Select | Backlog (gray), Researching (yellow), Ready (green) |
| Notes | Text | Rich text |

---

## Step 4: Import the Analytics Database

1. Import `analytics.csv`.
2. Rename to **Analytics**.

### Configure Column Types

| Column | Set Type To | Notes |
|--------|------------|-------|
| Content Title | Title | Auto-set |
| Platform | Select | Same options as other databases |
| Publish Date | Date | |
| Views | Number | Number format with commas |
| Likes | Number | |
| Comments | Number | |
| Shares | Number | |
| Click-through Rate | Text | Keep as text (includes % symbol) or use Number with Percent format |
| Revenue | Number | US Dollar format |

---

## Step 5: Set Up Relations

### Relation 1: Content Calendar → Ideas

1. In the Content Calendar database, add a **Relation** property.
2. Point it to the **Ideas** database.
3. Name it "Source Idea."
4. Reverse property on Ideas: "Content Created."
5. This lets you track which ideas became actual content.

### Relation 2: Analytics → Content Calendar

1. In Analytics, add a **Relation** to Content Calendar.
2. Name it "Content."
3. Reverse property on Content Calendar: "Performance."
4. Link each analytics entry to the content it tracks.

Now you can open any content piece and see both where the idea came from and how it performed.

---

## Step 6: Create Views

### Content Calendar Views

**View 1: Content Board (Kanban)**
1. Add a **Board** view named "Content Pipeline."
2. Group by: **Status**.
3. Columns: Idea | Drafting | Filming | Editing | Scheduled | Published.
4. This is your primary workflow view. Drag content cards as they progress.

*This view is where you will spend 80% of your time in CreatorHQ. It shows you exactly what is in your pipeline at every stage.*

**View 2: Publishing Calendar**
1. Add a **Calendar** view named "Schedule."
2. Set date property to **Publish Date**.
3. See your publishing schedule laid out by month. Spot gaps and overlaps instantly.

**View 3: By Platform**
1. Add a **Table** view named "By Platform."
2. Group by: **Platform**.
3. See all content organized by platform to ensure balanced distribution.

### Ideas Database Views

**View 4: Hot Ideas**
1. Add a **Table** view named "Hot Ideas."
2. Filter: Priority is "Hot."
3. Sort by: Status (Ready first, then Researching).
4. These are your next-up content pieces.

**View 5: Idea Board**
1. Add a **Board** view named "Idea Pipeline."
2. Group by: **Status**.
3. Columns: Backlog | Researching | Ready.

**View 6: By Source**
1. Add a **Table** view grouped by **Source**.
2. Helps you see where your best ideas come from.

### Analytics Database Views

**View 7: Top Performers**
1. Add a **Table** view named "Top Performers."
2. Sort by: Views (descending).
3. See your best content at a glance. Study what works and do more of it.

**View 8: By Platform**
1. Add a **Table** view grouped by **Platform**.
2. Compare performance across platforms.

**View 9: Revenue Generating**
1. Add a **Table** view filtered to Revenue is greater than 0.
2. Sort by Revenue descending.

---

## Step 7: Build Your Dashboard

On your main CreatorHQ page, build a command center:

**Section 1: Content Pipeline**
- Add a linked view of Content Calendar in Board view.
- Filter to Status is not "Published" (shows only active work).

**Section 2: Two Columns**
Left column:
- Heading: "Hot Ideas Ready to Create"
- Linked view of Ideas, filtered to Priority = Hot AND Status = Ready.

Right column:
- Heading: "Recently Published"
- Linked view of Content Calendar, filtered to Status = Published, sorted by Publish Date descending, limit to 5 entries.

**Section 3: Publishing Schedule**
- Linked view of Content Calendar in Calendar view.

**Section 4: Top Content**
- Linked view of Analytics sorted by Views descending, limited to top 5.

---

## Step 8: Customize and Replace Sample Data

1. Adjust the **Platform** options to match the platforms you actually use.
2. Update **Category** and **Topic** options to match your content pillars.
3. Start adding your real content alongside the samples.
4. Delete sample entries once you are comfortable with the system.

---

## Tips for Content Creators

- **Batch your content planning.** Spend one session per week moving ideas from Backlog to Ready, and scheduling content for the upcoming week.
- **Log analytics weekly.** Pick one day each week to pull numbers from each platform and record them. Consistency in tracking leads to better decisions.
- **Use the Ideas database liberally.** Every idea goes in, no matter how rough. The Priority system (Hot/Warm/Cold) keeps things organized without losing anything.
- **Review your Top Performers monthly.** Look for patterns in topics, formats, and platforms. Double down on what works.

---

## What Pro Adds

CreatorHQ Lite covers content planning and basic analytics. **CreatorHQ Pro** adds the business side of being a creator:

| Feature | Lite | Pro |
|---------|------|-----|
| Content Calendar | Yes | Yes |
| Ideas Pipeline | Yes | Yes |
| Analytics Tracking | Yes | Yes |
| **Brand Deals** | -- | Full sponsorship pipeline with rate tracking |
| **Monetization Tracker** | -- | All revenue streams in one dashboard |
| **Growth Log** | -- | Platform-by-platform follower and engagement tracking |
| **Collaborations** | -- | Track creator partnerships and collabs |
| **Revenue Dashboard** | -- | See exactly where your money comes from |
| **15+ Views** | 9 views | 15+ views including revenue and growth dashboards |
| **Cross-Database Relations** | 2 relations | 10+ relations connecting everything |

**Ready to treat your content like a real business?**
Upgrade to CreatorHQ Pro for $29 -- track your income, manage brand deals, and watch your growth with real data.

[Get CreatorHQ Pro →]

---

## Need Help?

- **Notion Import Help:** https://www.notion.so/help/import-data-into-notion
- **Questions?** Reply to your purchase confirmation email for setup assistance.

Happy creating.
